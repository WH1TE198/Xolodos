APP_BG      = "#F5F6FF"   # общий фон
HEADER_BG   = "#2C2F33"   # тёмная шапка
SIDEBAR_BG  = "#F3F4F8"   # светлый столбик слева
BTN_BORDER  = "#D2D5DC"   # рамки sidebar-кнопок
BTN_ICON    = "#6E7179"
PILL        = "#7B5AF3"   # фиолетовые карточки
STAT_BORDER = "#8E8E8E"   # бордер стат-блоков
